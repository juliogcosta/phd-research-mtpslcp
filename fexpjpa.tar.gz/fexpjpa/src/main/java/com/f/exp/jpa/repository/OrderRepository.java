package com.f.exp.jpa.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.f.exp.jpa.model.Order;

public interface OrderRepository extends JpaRepository<Order, Long> 
{
    Optional<Order> findByNumber(String number);
}