package com.f.exp.jpa.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.f.exp.jpa.rest.client.ModelerRESTClient;
import com.f.exp.jpa.rest.client.SQLDriverRESTClient;
import com.f.exp.jpa.service.QueryServiceImpl;
import com.yc.models.sql.internal.Project;
import com.yc.utils.ErrorControl;
import com.yc.utils.ErrorHandlerImpl;
import com.yc.utils.ExchangeSender;
import com.yc.utils.bean.LocalCacheImpl;

import br.edu.ufrn.loco3.Constant;

public class URLFilter implements Filter
{
    final Logger logger = LoggerFactory.getLogger(getClass());

    private String appName;

    public Boolean logDisplay;

    public Long ttl;

    private String contractXTenantID;

    private ModelerRESTClient modelerRESTClient;

    private SQLDriverRESTClient sqlDriverRESTClient;

    private QueryServiceImpl queryService;

    private LocalCacheImpl schemaCache;

    private ErrorControl errorControl;

    private ErrorHandlerImpl errorHandler = new ErrorHandlerImpl();

    private ExchangeSender exchangeSender;

    public void setAppName(String appName)
    {
        this.appName = appName;
    }

    public void setLogDisplay(Boolean logDisplay)
    {
        this.logDisplay = logDisplay;
    }

    public void setTtl(Long ttl)
    {
        this.ttl = ttl;
    }

    public void setContractXTenantID(String contractXTenantID)
    {
        this.contractXTenantID = contractXTenantID;
    }

    public void setModelerRESTClient(ModelerRESTClient modelerRESTClient)
    {
        this.modelerRESTClient = modelerRESTClient;
    }

    public void setSQLDriverRESTClient(SQLDriverRESTClient sqlDriverRESTClient)
    {
        this.sqlDriverRESTClient = sqlDriverRESTClient;
    }

    public void setQueryService(QueryServiceImpl queryService)
    {
        this.queryService = queryService;
    }

    public void setSchemaCache(LocalCacheImpl schemaCache)
    {
        this.schemaCache = schemaCache;
    }

    public void setErrorControl(ErrorControl localLogControl)
    {
        this.errorControl = localLogControl;
    }

    @Override
    public void init(FilterConfig filterConfig) throws ServletException
    {

    }

    @Override
    public void doFilter(ServletRequest servletRequest, 
            ServletResponse servletResponse, 
            FilterChain filterChain) throws IOException, ServletException
    {
        final HttpServletRequest request = (HttpServletRequest) servletRequest;
        final HttpServletResponse response = (HttpServletResponse) servletResponse;

        String tenantId = request.getHeader("X-Tenant-Id");

        final String xB3TraceId = request.getHeader("x-b3-traceid");
        final String xB3SpanId = request.getHeader("x-b3-spanid");
        final String xB3ParentSpanId = request.getHeader("x-b3-parentspanid");

        final JSONObject validTenantId = new JSONObject();
        validTenantId.put("validTenantId", false);

        try
        {
            if (tenantId == null) 
            {
                throw new Exception(String.valueOf(HttpStatus.BAD_REQUEST.value()).concat(":missing header X-Tenant-Id."));
            }
            else if (xB3TraceId == null) 
            {
                throw new Exception(String.valueOf(HttpStatus.BAD_REQUEST.value()).concat(":missing header x-b3-traceid."));
            }
            else if (this.schemaCache.containsKey(tenantId)) 
            {
                //logger.info("schema is alredy loaded ...");
            }
            else 
            {
               logger.info("calling URLFilter.loadSchema() ...");
                this.loadSchema(xB3TraceId, xB3SpanId, xB3ParentSpanId, tenantId, request.getMethod(), request.getRequestURI(), false, validTenantId);
            }

            filterChain.doFilter(request, servletResponse);
        }
        catch (Exception e)
        {
            if (!validTenantId.getBoolean("validTenantId") || tenantId == null)
            {
                JSONObject jsError = new JSONObject();
                jsError.put("message", e.getMessage());
                response.getWriter().write(jsError.toString());
                response.setStatus(HttpStatus.BAD_REQUEST.value());
            }
            else
            {
                Boolean containsKey = this.errorControl.containsKey(tenantId);
                if (containsKey) 
                {
                    if (this.errorControl.getLogConsole(tenantId)) 
                    {
                        e.printStackTrace();
                    }
                }
                else
                {
                    e.printStackTrace();
                }

                JSONObject jsError = new JSONObject(this.errorHandler.buildResponseEntityError(e, 
                        tenantId, 
                        xB3TraceId, 
                        xB3SpanId, 
                        xB3ParentSpanId, 
                        null, 
                        null, 
                        this.appName, 
                        request.getRequestURI(), 
                        request.getMethod(), 
                        null, 
                        null, 
                        containsKey ? this.errorControl.getSaveTrace(tenantId) : false,
                        containsKey ? this.errorControl.getSaveData(tenantId) : false));

                if (containsKey && this.errorControl.getSaveLog(tenantId)) 
                {
                    this.exchangeSender.sendMessageToInternalErrorExchange(jsError.toString());
                }

                response.getWriter().write(jsError.toString());
                response.setStatus(Integer.parseInt(jsError.getString("httpStatusCode")));
            }
        }
    }

    @Override
    public void destroy()
    {

    }

    public void loadSchema(String traceId,
            String spanId,
            String parentSpanId,
            String tenantId, 
            String httpMethod, 
            String httpEndpoint,
            Boolean isContract,
            JSONObject validTenantId) throws Exception
    {
        ResponseEntity<String> responseEntity = this.modelerRESTClient.getProjectByTenantId(traceId, spanId, parentSpanId, tenantId);
        if (responseEntity.getStatusCode() == HttpStatus.OK)
        {
            validTenantId.put("validTenantId", true);

            JSONObject jsProject = new JSONObject(responseEntity.getBody());

            if (isContract) 
            {
                if (!jsProject.getString("status").equals(Project.State.RUNNING.name()))
                {
                    throw new Exception(String.valueOf(HttpStatus.BAD_REQUEST.value()).concat(":schema for this tenantId '")
                            .concat(tenantId).concat("' is disabled to be running."));
                }

                JSONObject schema = null;

                responseEntity = this.sqlDriverRESTClient.getSchema(traceId, spanId, parentSpanId, tenantId);

                if (responseEntity.getStatusCode() == HttpStatus.OK)
                {
                    schema = new JSONObject(responseEntity.getBody());
                }
                else if (responseEntity.getStatusCode() == HttpStatus.NOT_FOUND)
                {
                    schema = new JSONObject();
                }
                else if (responseEntity.getStatusCode() == HttpStatus.NO_CONTENT)
                {
                    schema = new JSONObject();
                }
                else
                {
                    throw new Exception(String.valueOf(responseEntity.getStatusCode().value()).concat(": for tenantId '")
                            .concat(tenantId).concat("': ").concat(
                                    responseEntity.getBody() == null ? "no message." : responseEntity.getBody()));
                }

                if (schema.length() == 0)
                {
                    throw new Exception(String.valueOf(responseEntity.getStatusCode().value()).concat(":for this tenantId '")
                            .concat(tenantId).concat("': project not found."));
                }

                this.addSchema(tenantId, 
                        jsProject.getString(Constant.name), 
                        schema, 
                        jsProject.getString("apiMasterKey"), 
                        1000L*60*60*1);

                this.errorControl.initKey(tenantId, this.ttl, false);
                this.errorControl.setLogConsole(tenantId, this.logDisplay);
            }
            else
            {
                JSONObject jsContract = this.getContract(traceId, spanId, parentSpanId, jsProject.getString("owner"), httpMethod, httpEndpoint);

                this.addSchema(tenantId, 
                        jsProject.getString(Constant.name), 
                        new JSONObject(), 
                        jsProject.getString("apiMasterKey"), 
                        1000L*60*60*1);

                Boolean saveLog = jsContract.getJSONObject("plan").getString("name").equalsIgnoreCase("PRO") 
                        || jsContract.getJSONObject("plan").getString("name").equalsIgnoreCase("ENTERPRISE");
                this.errorControl.initKey(tenantId, this.ttl, false);
                this.errorControl.setLogConsole(tenantId, this.logDisplay);
                this.errorControl.setSaveLog(tenantId, saveLog);
            }
        }
        else
        {
            throw new Exception(String.valueOf(responseEntity.getStatusCode().value()).concat(": for tenantId '")
                    .concat(tenantId).concat("': ").concat(
                            responseEntity.getBody() == null ? "no message." : responseEntity.getBody()));
        }
    }

    private void addSchema(String tenantId, 
            String schemaName, 
            JSONObject schema, 
            String apiMasterKey, 
            Long ttl)
    {
        JSONObject map = new JSONObject();
        map.put("SCHEMA_NAME", schemaName);

        JSONArray reverseKeys = new JSONArray();
        reverseKeys.put(apiMasterKey);

        this.schemaCache.save(tenantId, reverseKeys, schema, map, ttl);
    }

    private JSONObject getContract(String traceId,
            String spanId,
            String parentSpanId,
            String organizationUuid, 
            String httpMethod, 
            String httpEndpoint) throws Exception
    {
        JSONObject _jsContract = new JSONObject();
        _jsContract.put("id", "");
        _jsContract.put("organizationuuid", organizationUuid);
        _jsContract.put("status", "");
        _jsContract.put("uuid", "");
        _jsContract.put("hiredin", "");
        _jsContract.put("expiresin", "");
        _jsContract.put("logversion", "");
        _jsContract.put("plan", new JSONObject());
        _jsContract.getJSONObject("plan").put("id", "");
        _jsContract.getJSONObject("plan").put("name", "");
        _jsContract.getJSONObject("plan").put("ttl", "");
        _jsContract.getJSONObject("plan").put("threshold", "");
        _jsContract.getJSONObject("plan").put("ppo", "");
        _jsContract.getJSONObject("plan").put("logversion", "");
        JSONObject jsData = new JSONObject();
        jsData.put("contract", _jsContract);

        JSONArray jsQuery = new JSONArray();
        jsQuery.put(jsData);

        JSONObject jsContract = null;

        if (!this.schemaCache.containsKey(this.contractXTenantID))
        {
            JSONObject validTenantId = new JSONObject();
            validTenantId.put("validTenantId", true);
            this.loadSchema(traceId, spanId, parentSpanId, this.contractXTenantID, httpMethod, httpEndpoint, true, validTenantId);
        }

        JSONArray datas = this.queryService.readByCriteria(traceId, spanId, parentSpanId, this.contractXTenantID, jsQuery, null);

        JSONArray jsContracts = datas.getJSONObject(0).getJSONArray("contract");

        int count = 0;

        for (int idx = 0; idx < jsContracts.length(); idx++)
        {
            if (jsContracts.getJSONObject(idx).getString("status").equals("ACTIVE"))
            {
                jsContract = jsContracts.getJSONObject(idx);

                count++;
            }

            if (count > 1) 
            {
                throw new Exception("417:this organization '".concat(organizationUuid).concat("' has more than one contract active."));
            }
        }

        if (jsContract == null)
        {
            throw new Exception("204:contract not found");
        }

        return jsContract;
    }
}
