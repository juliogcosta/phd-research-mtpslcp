package com.f.exp.jpa;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.f.exp.jpa.filter.URLFilter;
import com.f.exp.jpa.rest.client.ModelerRESTClient;
import com.f.exp.jpa.rest.client.SQLDriverRESTClient;
import com.f.exp.jpa.service.QueryServiceImpl;
import com.yc.utils.ErrorControl;
import com.yc.utils.bean.LocalCacheImpl;

@Configuration
public class ConfigFilter
{
    @Value("${yc.baas.project.contract.x-tenant-id}")
    private String contractXTenantID;

    @Value("${spring.application.name}")
    public String appName;

    @Value("${yc.api.management.server.log.control.display}")
    public Boolean logDisplay;

    @Value("${yc.api.management.server.log.control.data.persistence.ttl}")
    public Long ttl;

    @Autowired
    private ModelerRESTClient modelerRESTClient;

    @Autowired
    private SQLDriverRESTClient sqlDriverRESTClient;

    @Autowired
    private QueryServiceImpl queryService;

    @Autowired
    private LocalCacheImpl schemaCache;

    @Autowired
    private ErrorControl errorControl;

    @Bean
    public FilterRegistrationBean<URLFilter> filterRegistrationBean()
    {
        final URLFilter urlFilter = new URLFilter();
        urlFilter.setAppName(this.appName);
        urlFilter.setLogDisplay(this.logDisplay);
        urlFilter.setTtl(this.ttl);
        urlFilter.setModelerRESTClient(this.modelerRESTClient);
        urlFilter.setSQLDriverRESTClient(this.sqlDriverRESTClient);
        urlFilter.setSchemaCache(this.schemaCache);
        urlFilter.setErrorControl(this.errorControl);
        urlFilter.setQueryService(this.queryService);
        urlFilter.setContractXTenantID(this.contractXTenantID);

        final FilterRegistrationBean<URLFilter> registrationBean = new FilterRegistrationBean<>();
        registrationBean.setFilter(urlFilter);
        registrationBean.addUrlPatterns("/sec/*", "/unsec/*");
        //registrationBean.addUrlPatterns("/s/*", "/m/*", UnsecuredServiceController.urlPrefix.concat("/*"));
        registrationBean.setOrder(2);

        return registrationBean;
    }
}
