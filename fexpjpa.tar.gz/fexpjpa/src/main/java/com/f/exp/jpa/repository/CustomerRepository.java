package com.f.exp.jpa.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.f.exp.jpa.model.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Long> 
{
    public List<Customer> findByName(String name);

    public Optional<Customer> findByDoc(String name);
}