package com.f.exp.jpa;

import javax.annotation.PreDestroy;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.UserDetailsServiceAutoConfiguration;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.yc.pr.sec.AccessTokenFilter;
import com.yc.pr.sec.JwtAccessDeniedHandler;
import com.yc.pr.sec.JwtAuthenticationEntryPoint;
import com.yc.pr.sec.JwtUtils;

import feign.Contract;

@EnableEurekaClient
@EnableWebSecurity
@EnableFeignClients
@ComponentScan(basePackages = { "com.f.exp.jpa", "com.yc.utils.bean" })
@SpringBootApplication(exclude = { UserDetailsServiceAutoConfiguration.class })
public class Application implements CommandLineRunner
{
    final Logger logger = LoggerFactory.getLogger(getClass());

    @Value("${yc.api.management.server.log.control.display}")
    public Boolean logDisplay;

    @Value("${yc.security.keys.accessToken.secret}") 
    private String accessTokenSecret;

    @Value("${yc.security.keys.accessToken.expirationMinutes}") 
    private int accessTokenExpirationMinutes;

    @Value("${yc.security.keys.refreshToken.secret}") 
    private String refreshTokenSecret;

    @Value("${yc.security.keys.refreshToken.expirationDays}") 
    private int refreshTokenExpirationDays;
    
    @Value("${spring.datasource.url}")
    private String dsUrl;
    
    @Value("${spring.datasource.username}")
    private String dsUsername;
    
    @Value("${spring.datasource.password}")
    private String dsPassword;
    
    @Bean
    public Contract feignContract()
    {
        return new feign.Contract.Default();
    }

    public static void main(String[] args)
    {
        SpringApplication.run(Application.class, args);
    }

    @Bean
    public JwtUtils jwtUtils() 
    {
        return new JwtUtils(
                this.accessTokenSecret, 
                this.accessTokenExpirationMinutes, 
                this.refreshTokenSecret, 
                this.refreshTokenExpirationDays);
    }

    @Bean
    public AccessTokenFilter accessTokenFilter() 
    {
        return new AccessTokenFilter();
    }

    @Bean
    public JwtAuthenticationEntryPoint jwtAuthenticationEntryPoint() 
    {
        return new JwtAuthenticationEntryPoint();
    }

    @Bean
    public JwtAccessDeniedHandler jwtAccessDeniedHandler() 
    {
        return new JwtAccessDeniedHandler();
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception
    {
        http.csrf().disable() 
                .exceptionHandling()
                    .authenticationEntryPoint(this.jwtAuthenticationEntryPoint())
                    .accessDeniedHandler(this.jwtAccessDeniedHandler())
            .and()
                .sessionManagement() 
                        .sessionCreationPolicy(SessionCreationPolicy.STATELESS) 
            .and()
                .authorizeHttpRequests() 
                    /*
                     * Sobre os endpoints de monitoramento
                     * 
                     */
                    .antMatchers("/actuator/**").hasRole("YC_API_ACTUATOR")

                    /*
                     * Authenticated endpoints
                     * 
                     */
                    .antMatchers("/sec/**").authenticated()
                    .antMatchers("/unsec/**").permitAll()

                    /*
                     * Sobre Endpoints sem Segurança
                     * 
                     */
                    .antMatchers("/swagger-ui.html").permitAll()
                    .antMatchers("/swagger-ui/**").permitAll()
                    .antMatchers("/v3/api-docs/**").permitAll()

                    .anyRequest().authenticated();

        http.addFilterBefore(this.accessTokenFilter(), UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }

    @Bean
    public WebMvcConfigurer corsConfigurer() 
    {
        return new WebMvcConfigurer() {
            @Override
            public void addCorsMappings(CorsRegistry registry) 
            {
                registry.addMapping("/**")
                    .allowCredentials(true)
                    .allowedOriginPatterns("*")
                    .allowedHeaders(
                            HttpHeaders.ORIGIN,
                            HttpHeaders.ACCESS_CONTROL_ALLOW_CREDENTIALS,
                            HttpHeaders.ACCESS_CONTROL_ALLOW_ORIGIN,
                            HttpHeaders.AUTHORIZATION,
                            HttpHeaders.CONTENT_TYPE,
                            HttpHeaders.ACCEPT)
                    .allowedMethods(
                            HttpMethod.POST.name(), 
                            HttpMethod.GET.name(), 
                            HttpMethod.PUT.name(), 
                            HttpMethod.DELETE.name(), 
                            HttpMethod.OPTIONS.name());
            }
        };
    }

    @Override
    public void run(String... args) throws Exception
    {

    }

    @PreDestroy
    public void onExit()
    {

    }
}
