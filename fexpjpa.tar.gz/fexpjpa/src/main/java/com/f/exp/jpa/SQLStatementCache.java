package com.f.exp.jpa;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yc.utils.bean.LocalSQLStatementCacheImpl;

import br.edu.ufrn.loco3.schema.SQLStatementService;

@Service
public class SQLStatementCache implements SQLStatementService
{
    @Autowired
    private LocalSQLStatementCacheImpl localSQLStatementCacheImpl;

    public void addSQLStatement(String tenantId, String queryId, String queryType, String query)
    {
        this.localSQLStatementCacheImpl.save(tenantId, queryId, queryType, query);
    }

    public Boolean existSQLStatement(String tenantId, String queryId, String queryType)
    {
        return this.localSQLStatementCacheImpl.exist(tenantId, queryId, queryType);
    }

    public void dropSQLStatement(String tenantId, String queryId, String queryType) throws Exception
    {
        this.localSQLStatementCacheImpl.remove(tenantId, queryId, queryType);
    }

    @Override
    public String getSQLStatement(String tenantId, String queryId, String queryType)
    {
        return this.localSQLStatementCacheImpl.get(tenantId, queryId, queryType);
    }
}

