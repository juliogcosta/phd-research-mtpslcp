package com.f.exp.jpa.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Transient;
import javax.persistence.Column;
import javax.persistence.Table;

@Entity
@Table(name = "order", schema = "fexpzero")
public class Order
{
    @Id
    @SequenceGenerator(name="order_pk_sequence",sequenceName="fexpzero.order_id_seq", allocationSize=1)
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="order_pk_sequence")
    private long id;

    @ManyToOne
    @JoinColumn(name = "customer")
    private Customer customer;

    @ManyToOne
    @JoinColumn(name = "ordertype")
    private OrderType orderType;

    @Column(name = "number", unique = true)
    private String number;

    @Column(name = "notes")
    private String notes;

    @Column(name = "date")
    private Date date;

    @Transient
    private String total;

    public Order() { }

    public Order(String number, String notes, Date date) {
        this.number = number;
        this.notes = notes;
        this.date = date;
    }

    public long getId()
    {
        return id;
    }

    public Customer getCustomer()
    {
        return customer;
    }

    public void setCustomer(Customer customer)
    {
        this.customer = customer;
    }

    public OrderType getOrderType()
    {
        return orderType;
    }

    public void setOrderType(OrderType orderType)
    {
        this.orderType = orderType;
    }

    public String getNumber()
    {
        return number;
    }

    public void setNumber(String name)
    {
        this.number = name;
    }

    public String getNotes()
    {
        return notes;
    }

    public void setNotes(String local)
    {
        this.notes = local;
    }

    public Date getDate()
    {
        return date;
    }

    public void setDate(Date date)
    {
        this.date = date;
    }

    public String getTotal()
    {
        return total;
    }

    public void setTotal(String total)
    {
        this.total = total;
    }

    @Override
    public String toString()
    {
        return "Order [id=" + id + ", number=" + number + ", notes=" + notes + ", date=" + date + ", total=" + total + "]";
    }
}
