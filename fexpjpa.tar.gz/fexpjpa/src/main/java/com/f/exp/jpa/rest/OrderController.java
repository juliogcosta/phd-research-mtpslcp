package com.f.exp.jpa.rest;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.HandlerMapping;

import com.f.exp.jpa.model.Order;
import com.f.exp.jpa.repository.CustomerRepository;
import com.f.exp.jpa.repository.OrderRepository;
import com.f.exp.jpa.repository.OrderTypeRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.yc.models.nosql.Consumption;

@RestController
@RequestMapping("/unsec/orders")
public class OrderController extends Controller
{
    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private OrderTypeRepository orderTypeRepository;

    @Autowired
    private CustomerRepository customerRepository;

    @GetMapping
    public ResponseEntity<String> getAllOrders(@RequestHeader(name = "X-Tenant-Id", required = true) String tenantId,
            @RequestHeader(name = "X-API-Master-Key", required = true) String apiMasterKey,
            @RequestHeader(name = "x-b3-traceid", required = true) String b3Traceid,
            @RequestHeader(name = "x-b3-spanid", required = true) String b3Spanid,
            @RequestHeader(name = "x-b3-parentspanid", required = true) String b3Parentspanid,
            HttpServletRequest request)
    {
        long onStart = System.currentTimeMillis();

        String responseBody = null;
        int action = -1;

        try
        {
            List<Order> orders = new ArrayList<Order>();
            orderRepository.findAll().forEach(order -> {
                orders.add(order);
            });

            if (orders.isEmpty())
            {
                responseBody = "[]";
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            responseBody = new ObjectMapper().writeValueAsString(orders);
            return new ResponseEntity<>(responseBody, HttpStatus.OK);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        finally
        {
            if (responseBody == null)
            {
                this.registerConsumption(tenantId,
                        this.appName.concat(
                                request.getAttribute(HandlerMapping.PATH_WITHIN_HANDLER_MAPPING_ATTRIBUTE).toString()),
                        0, Consumption.Type.Response.ordinal(), action, onStart, System.currentTimeMillis() - onStart);
            }
            else
            {
                this.registerConsumption(tenantId,
                        this.appName.concat(
                                request.getAttribute(HandlerMapping.PATH_WITHIN_HANDLER_MAPPING_ATTRIBUTE).toString()),
                        responseBody.length(), Consumption.Type.Response.ordinal(), action, onStart,
                        System.currentTimeMillis() - onStart);
            }
        }
    }

    @GetMapping("/number/{number}")
    public ResponseEntity<String> getOrdersByNumber(
            @RequestHeader(name = "X-Tenant-Id", required = true) String tenantId,
            @RequestHeader(name = "X-API-Master-Key", required = true) String apiMasterKey,
            @RequestHeader(name = "x-b3-traceid", required = true) String b3Traceid,
            @RequestHeader(name = "x-b3-spanid", required = true) String b3Spanid,
            @RequestHeader(name = "x-b3-parentspanid", required = true) String b3Parentspanid,
            @PathVariable(required = false) String number, HttpServletRequest request)
    {
        long onStart = System.currentTimeMillis();

        String responseBody = null;
        int action = -1;

        try
        {
            List<Order> orders = new ArrayList<Order>();
            orderRepository.findByNumber(number).ifPresent(order -> {
                orders.add(order);
            });

            if (orders.isEmpty())
            {
                responseBody = "[]";
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            responseBody = new ObjectMapper().writeValueAsString(orders);
            return new ResponseEntity<>(responseBody, HttpStatus.OK);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        finally
        {
            if (responseBody == null)
            {
                this.registerConsumption(tenantId,
                        this.appName.concat(
                                request.getAttribute(HandlerMapping.PATH_WITHIN_HANDLER_MAPPING_ATTRIBUTE).toString()),
                        0, Consumption.Type.Response.ordinal(), action, onStart, System.currentTimeMillis() - onStart);
            }
            else
            {
                this.registerConsumption(tenantId,
                        this.appName.concat(
                                request.getAttribute(HandlerMapping.PATH_WITHIN_HANDLER_MAPPING_ATTRIBUTE).toString()),
                        responseBody.length(), Consumption.Type.Response.ordinal(), action, onStart,
                        System.currentTimeMillis() - onStart);
            }
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<String> getOrderById(@RequestHeader(name = "X-Tenant-Id", required = true) String tenantId,
            @RequestHeader(name = "X-API-Master-Key", required = true) String apiMasterKey,
            @RequestHeader(name = "x-b3-traceid", required = true) String b3Traceid,
            @RequestHeader(name = "x-b3-spanid", required = true) String b3Spanid,
            @RequestHeader(name = "x-b3-parentspanid", required = true) String b3Parentspanid,
            @PathVariable("id") long id, HttpServletRequest request)
    {
        long onStart = System.currentTimeMillis();

        String responseBody = null;
        int action = -1;

        try
        {
            Optional<Order> optional = orderRepository.findById(id);
            if (optional.isPresent())
            {
                responseBody = new ObjectMapper().writeValueAsString(optional.get());
                return new ResponseEntity<>(responseBody, HttpStatus.OK);
            }
            else
            {
                responseBody = "{}";
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        finally
        {
            if (responseBody == null)
            {
                this.registerConsumption(tenantId,
                        this.appName.concat(
                                request.getAttribute(HandlerMapping.PATH_WITHIN_HANDLER_MAPPING_ATTRIBUTE).toString()),
                        0, Consumption.Type.Response.ordinal(), action, onStart, System.currentTimeMillis() - onStart);
            }
            else
            {
                this.registerConsumption(tenantId,
                        this.appName.concat(
                                request.getAttribute(HandlerMapping.PATH_WITHIN_HANDLER_MAPPING_ATTRIBUTE).toString()),
                        responseBody.length(), Consumption.Type.Response.ordinal(), action, onStart,
                        System.currentTimeMillis() - onStart);
            }
        }
    }

    @PostMapping
    public ResponseEntity<Order> createOrder(@RequestHeader(name = "X-Tenant-Id", required = true) String tenantId,
            @RequestHeader(name = "X-API-Master-Key", required = true) String apiMasterKey,
            @RequestHeader(name = "x-b3-traceid", required = true) String b3Traceid,
            @RequestHeader(name = "x-b3-spanid", required = true) String b3Spanid,
            @RequestHeader(name = "x-b3-parentspanid", required = true) String b3Parentspanid, 
            @RequestBody String body,
            HttpServletRequest request)
    {
        long onStart = System.currentTimeMillis();

        String responseBody = null;
        int action = -1;

        try
        {
            Order order = new ObjectMapper().readValue(body.getBytes(), Order.class);
            Order _order = new Order(order.getNumber(), order.getNotes(), order.getDate());
            _order.setCustomer(customerRepository.findById(1L).get());
            _order.setOrderType(orderTypeRepository.findById(1L).get());
            return new ResponseEntity<>(orderRepository.save(_order), HttpStatus.CREATED);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        finally
        {
            if (responseBody == null)
            {
                this.registerConsumption(tenantId,
                        this.appName.concat(
                                request.getAttribute(HandlerMapping.PATH_WITHIN_HANDLER_MAPPING_ATTRIBUTE).toString()),
                        0, Consumption.Type.Response.ordinal(), action, onStart, System.currentTimeMillis() - onStart);
            }
            else
            {
                this.registerConsumption(tenantId,
                        this.appName.concat(
                                request.getAttribute(HandlerMapping.PATH_WITHIN_HANDLER_MAPPING_ATTRIBUTE).toString()),
                        responseBody.length(), Consumption.Type.Response.ordinal(), action, onStart,
                        System.currentTimeMillis() - onStart);
            }
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<Order> updateOrder(
            @RequestHeader(name = "X-Tenant-Id", required = true) String tenantId,
            @RequestHeader(name = "X-API-Master-Key", required = true) String apiMasterKey,
            @RequestHeader(name = "x-b3-traceid", required = true) String b3Traceid,
            @RequestHeader(name = "x-b3-spanid", required = true) String b3Spanid,
            @RequestHeader(name = "x-b3-parentspanid", required = true) String b3Parentspanid,
            @PathVariable("id") long id, 
            @RequestBody String body, HttpServletRequest request)
    {
        long onStart = System.currentTimeMillis();

        int action = -1;

        try
        {
            Optional<Order> optional = orderRepository.findById(id);
            if (optional.isPresent())
            {
                Order order = new ObjectMapper().readValue(body.getBytes(), Order.class);

                Order _order = optional.get();
                _order.setNumber(order.getNumber());
                _order.setNotes(order.getNotes());
                _order.setDate(order.getDate());
                return new ResponseEntity<>(orderRepository.save(_order), HttpStatus.OK);
            }
            else
            {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        finally
        {
            this.registerConsumption(tenantId,
                    this.appName.concat(
                            request.getAttribute(HandlerMapping.PATH_WITHIN_HANDLER_MAPPING_ATTRIBUTE).toString()),
                    0, Consumption.Type.Response.ordinal(), action, onStart, System.currentTimeMillis() - onStart);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<HttpStatus> deleteOrder(@PathVariable("id") long id)
    {
        try
        {
            orderRepository.deleteById(id);
            return new ResponseEntity<>(HttpStatus.OK);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping
    public ResponseEntity<HttpStatus> deleteAllOrder()
    {
        try
        {
            orderRepository.deleteAll();
            return new ResponseEntity<>(HttpStatus.OK);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
