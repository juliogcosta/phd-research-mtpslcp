package com.f.exp.jpa.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "ordertype", schema = "fexpzero")
public class OrderType
{
    @Id
    @SequenceGenerator(name="ordertype_pk_sequence",sequenceName="fexpzero.ordertype_id_seq", allocationSize=1)
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="ordertype_pk_sequence")
    private long id;

    @OneToMany(mappedBy = "orderType", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Order> orders = new ArrayList<Order>();

    @Column(name = "type", unique = true)
    private String type;

    public OrderType() { }

    public OrderType(String type) 
    {
        this.type = type;
    }

    public long getId()
    {
        return id;
    }

    public String getType()
    {
        return type;
    }

    public void setType(String type)
    {
        this.type = type;
    }

    @Override
    public String toString()
    {
        return "OrderType [id=" + id + ", type=" + type + "]";
    }

}
