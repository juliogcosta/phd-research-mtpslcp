package com.f.exp.jpa.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "customer", schema = "fexpzero")
public class Customer
{
    @Id
    @SequenceGenerator(name="customer_pk_sequence",sequenceName="fexpzero.customer_id_seq", allocationSize=1)
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="customer_pk_sequence")
    private long id;

    @OneToMany(mappedBy = "customer", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Order> orders = new ArrayList<Order>();

    @Column(name = "name")
    private String name;

    @Column(name = "doc", unique = true)
    private String doc;

    public Customer() { }

    public Customer(String name, String doc) 
    {
        this.name = name;
        this.doc = doc;
    }

    public long getId()
    {
        return id;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getDoc()
    {
        return doc;
    }

    public void setDoc(String email)
    {
        this.doc = email;
    }

    @Override
    public String toString()
    {
        return "Customer [id=" + id + ", name=" + name + ", doc=" + doc + "]";
    }

}
