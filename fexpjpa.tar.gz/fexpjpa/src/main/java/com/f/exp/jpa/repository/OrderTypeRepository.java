package com.f.exp.jpa.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.f.exp.jpa.model.OrderType;

public interface OrderTypeRepository extends JpaRepository<OrderType, Long> 
{
    public Optional<OrderType> findByType(String ype);
}