package com.f.exp.jpa.rest;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.HandlerMapping;

import com.f.exp.jpa.model.Customer;
import com.f.exp.jpa.repository.CustomerRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.yc.models.nosql.Consumption;

@RestController
@RequestMapping("/unsec/customers")
public class CustomerController extends Controller
{
    @Autowired
    private CustomerRepository customerRepository;

    @GetMapping
    public ResponseEntity<String> getAllCustomers(@RequestHeader(name = "X-Tenant-Id", required = true) String tenantId,
            @RequestHeader(name = "X-API-Master-Key", required = true) String apiMasterKey,
            HttpServletRequest request)
    {
       logger.info("in CustomerController.getAllCustomers()!");
        long onStart = System.currentTimeMillis();

        String responseBody = null;
        int action = -1;

        try
        {
            List<Customer> customers = new ArrayList<Customer>();
            customerRepository.findAll().forEach(customer -> {
                customers.add(customer);
            });
            
            if (customers.isEmpty())
            {
                responseBody = "[]";
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
            
            responseBody = new ObjectMapper().writeValueAsString(customers);
            return new ResponseEntity<>(responseBody, HttpStatus.OK);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        finally
        {
            if (responseBody == null)
            {
                this.registerConsumption(tenantId,
                        this.appName.concat(
                                request.getAttribute(HandlerMapping.PATH_WITHIN_HANDLER_MAPPING_ATTRIBUTE).toString()),
                        0, Consumption.Type.Response.ordinal(), action, onStart, System.currentTimeMillis() - onStart);
            }
            else
            {
                this.registerConsumption(tenantId,
                        this.appName.concat(
                                request.getAttribute(HandlerMapping.PATH_WITHIN_HANDLER_MAPPING_ATTRIBUTE).toString()),
                        responseBody.length(), Consumption.Type.Response.ordinal(), action, onStart,
                        System.currentTimeMillis() - onStart);
            }
        }
    }

    @GetMapping("/name/{name}")
    public ResponseEntity<String> getCustomersByName(
            @RequestHeader(name = "X-Tenant-Id", required = true) String tenantId,
            @RequestHeader(name = "X-API-Master-Key", required = true) String apiMasterKey,
            @PathVariable(required = false) String name, HttpServletRequest request)
    {
        long onStart = System.currentTimeMillis();

        String responseBody = null;
        int action = -1;

        try
        {
            List<Customer> customers = new ArrayList<Customer>();
            customerRepository.findByName(name).forEach(customer -> {
                customers.add(customer);
            });

            if (customers.isEmpty())
            {
                responseBody = "[]";
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            responseBody = new ObjectMapper().writeValueAsString(customers);
            return new ResponseEntity<>(responseBody, HttpStatus.OK);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        finally
        {
            if (responseBody == null)
            {
                this.registerConsumption(tenantId,
                        this.appName.concat(
                                request.getAttribute(HandlerMapping.PATH_WITHIN_HANDLER_MAPPING_ATTRIBUTE).toString()),
                        0, Consumption.Type.Response.ordinal(), action, onStart, System.currentTimeMillis() - onStart);
            }
            else
            {
                this.registerConsumption(tenantId,
                        this.appName.concat(
                                request.getAttribute(HandlerMapping.PATH_WITHIN_HANDLER_MAPPING_ATTRIBUTE).toString()),
                        responseBody.length(), Consumption.Type.Response.ordinal(), action, onStart,
                        System.currentTimeMillis() - onStart);
            }
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<String> getCustomerById(@RequestHeader(name = "X-Tenant-Id", required = true) String tenantId,
            @RequestHeader(name = "X-API-Master-Key", required = true) String apiMasterKey,
            @PathVariable("id") long id, HttpServletRequest request)
    {
        long onStart = System.currentTimeMillis();

        String responseBody = null;
        int action = -1;

        try
        {
            Optional<Customer> optional = customerRepository.findById(id);
            if (optional.isPresent())
            {
                responseBody = new ObjectMapper().writeValueAsString(optional.get());
                return new ResponseEntity<>(responseBody, HttpStatus.OK);
            }
            else
            {
                responseBody = "{}";
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        finally
        {
            if (responseBody == null)
            {
                this.registerConsumption(tenantId,
                        this.appName.concat(
                                request.getAttribute(HandlerMapping.PATH_WITHIN_HANDLER_MAPPING_ATTRIBUTE).toString()),
                        0, Consumption.Type.Response.ordinal(), action, onStart, System.currentTimeMillis() - onStart);
            }
            else
            {
                this.registerConsumption(tenantId,
                        this.appName.concat(
                                request.getAttribute(HandlerMapping.PATH_WITHIN_HANDLER_MAPPING_ATTRIBUTE).toString()),
                        responseBody.length(), Consumption.Type.Response.ordinal(), action, onStart,
                        System.currentTimeMillis() - onStart);
            }
        }
    }

    @PostMapping
    public ResponseEntity<String> createCustomer(@RequestHeader(name = "X-Tenant-Id", required = true) String tenantId,
            @RequestHeader(name = "X-API-Master-Key", required = true) String apiMasterKey,
            @RequestBody String body,
            HttpServletRequest request)
    {
        long onStart = System.currentTimeMillis();

        String responseBody = null;
        int action = -1;

        try
        {
            Customer customer = new ObjectMapper().readValue(body.getBytes(), Customer.class);
            responseBody = new ObjectMapper()
                    .writeValueAsString(customerRepository.save(new Customer(customer.getName(), customer.getDoc())));
            return new ResponseEntity<>(responseBody, HttpStatus.CREATED);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        finally
        {
            if (responseBody == null)
            {
                this.registerConsumption(tenantId,
                        this.appName.concat(
                                request.getAttribute(HandlerMapping.PATH_WITHIN_HANDLER_MAPPING_ATTRIBUTE).toString()),
                        0, Consumption.Type.Response.ordinal(), action, onStart, System.currentTimeMillis() - onStart);
            }
            else
            {
                this.registerConsumption(tenantId,
                        this.appName.concat(
                                request.getAttribute(HandlerMapping.PATH_WITHIN_HANDLER_MAPPING_ATTRIBUTE).toString()),
                        responseBody.length(), Consumption.Type.Response.ordinal(), action, onStart,
                        System.currentTimeMillis() - onStart);
            }
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<Customer> updateCustomer(
            @RequestHeader(name = "X-Tenant-Id", required = true) String tenantId,
            @RequestHeader(name = "X-API-Master-Key", required = true) String apiMasterKey,
            @PathVariable("id") long id, 
            @RequestBody(required = true) String body, HttpServletRequest request)
    {
        long onStart = System.currentTimeMillis();

        int action = -1;

        try
        {
          Customer customer = new ObjectMapper().readValue(body.getBytes(), Customer.class);

          return new ResponseEntity<>(customerRepository.save(customer), HttpStatus.OK);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        finally
        {
            this.registerConsumption(tenantId,
                    this.appName.concat(
                            request.getAttribute(HandlerMapping.PATH_WITHIN_HANDLER_MAPPING_ATTRIBUTE).toString()),
                    0, Consumption.Type.Response.ordinal(), action, onStart, System.currentTimeMillis() - onStart);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<HttpStatus> deleteCustomer(@PathVariable("id") long id)
    {
        try
        {
            customerRepository.deleteById(id);
            return new ResponseEntity<>(HttpStatus.OK);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping
    public ResponseEntity<HttpStatus> deleteAllCustomer()
    {
        try
        {
            customerRepository.deleteAll();
            return new ResponseEntity<>(HttpStatus.OK);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
