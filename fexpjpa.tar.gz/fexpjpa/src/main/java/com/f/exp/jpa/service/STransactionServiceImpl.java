package com.f.exp.jpa.service;

import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.f.exp.jpa.SQLStatementCache;
import com.f.exp.jpa.rest.client.SQLDriverRemoteImpl;
import com.yc.utils.bean.LocalCacheImpl;

import br.edu.ufrn.loco3.Constant;
import br.edu.ufrn.loco3.security.UserAuthorizationService;
import br.edu.ufrn.loco3.transformers.BusinessRuleService;
import br.edu.ufrn.loco3.transformers.mutations.CreateStatementTransformation;
import br.edu.ufrn.loco3.transformers.mutations.DeleteStatementTransformation;
import br.edu.ufrn.loco3.transformers.mutations.UpdateStatementTransformation;

@Service
public class STransactionServiceImpl
{
    final Logger logger = LoggerFactory.getLogger(getClass());

    @Autowired
    private QueryServiceImpl queryService;

    @Autowired
    private SQLDriverRemoteImpl sqlDriverRemote;

    @Autowired
    private LocalCacheImpl schemaCache;

    @Autowired
    private SQLStatementCache sqlStatementCacheWrapper;

    @Autowired
    private BusinessRuleService businessRuleService;

    public void create(String traceId, String spanId, String parentSpanId, String tenantId, JSONArray datas, UserAuthorizationService userAuthorizationService) throws Exception
    {
        CreateStatementTransformation transformer = new CreateStatementTransformation(
                new SchemaCacheWrapper(this.schemaCache), this.sqlStatementCacheWrapper);

        JSONObject sqlStatements = new JSONObject();
        JSONObject noSQLStatements = new JSONObject();
        for (int idx = 0; idx < datas.length(); idx++)
        {
            JSONObject statement = transformer.getStatement(tenantId, datas.getJSONObject(idx), userAuthorizationService, this.businessRuleService);
            if (statement.getString(Constant.dbType).equals(Constant.sql)) 
            {
                sqlStatements.put(String.valueOf(idx), statement);
            }
            else
            {
                noSQLStatements.put(String.valueOf(idx), statement);
            }
        }

        if (sqlStatements.length() > 0)
        {
            final JSONObject executedSQLStatements = new JSONObject(this.sqlDriverRemote.toInsert(traceId, spanId, parentSpanId, tenantId, sqlStatements.toString()));
            for (String executedSQLStatementKey : executedSQLStatements.keySet()) 
            {
                JSONObject data = datas.getJSONObject(Integer.parseInt(executedSQLStatementKey));
                this.setDataTreeIdValues(executedSQLStatements.getJSONObject(executedSQLStatementKey), data);

                JSONObject sqlStatement = sqlStatements.getJSONObject(executedSQLStatementKey);
                if (sqlStatement.has(Constant.call))
                {
                    JSONObject brCallDef = sqlStatement.getJSONObject(Constant.call);
                    for (int idx = 0; idx < brCallDef.getJSONArray(Constant.after).length(); idx++) 
                    {
                        String uri = brCallDef.getJSONArray(Constant.after).getString(idx);
                        try
                        {
                            JSONObject rData = this.businessRuleService.brCall(uri, "after", "create", data);
                            datas.put(Integer.parseInt(executedSQLStatementKey), rData);
                        }
                        catch (Exception e)
                        {
                            throw new RuntimeException("417?:an error occurred while calling the business rule for data pos-processing. [to: ".concat(uri).concat("]"), e);
                        }
                    }
                }
            }
        }

        if (noSQLStatements.length() > 0)
        {
            /*
            datas = new JSONArray();
            this.noSQLDriverRemote.toInsert(tenantId, noSQLStatements.toString());
            
            for (String noSQLStatementKey : noSQLStatements.keySet()) 
            {
                JSONObject noSQLStatement = noSQLStatements.getJSONObject(noSQLStatementKey);
                if (noSQLStatement.has(Constant.call))
                {
                    datas.put(businessRuleService.brCall(noSQLStatement.getJSONObject(Constant.call).getString(Constant.uri), data));
                }
            }
             */
        }
    }

    public JSONObject getCreateStatement(String tenantId, JSONArray datas, UserAuthorizationService userAuthorizationService) throws Exception
    {
        CreateStatementTransformation transformer = new CreateStatementTransformation(
                new SchemaCacheWrapper(this.schemaCache), this.sqlStatementCacheWrapper);

        JSONObject sqlStatements = new JSONObject();
        JSONObject noSQLStatements = new JSONObject();
        for (int idx = 0; idx < datas.length(); idx++)
        {
            JSONObject statement = transformer.getStatement(tenantId, datas.getJSONObject(idx), userAuthorizationService, this.businessRuleService);
            if (statement.getString(Constant.dbType).equals(Constant.sql)) 
            {
                sqlStatements.put(String.valueOf(idx), statement);
            }
            else
            {
                noSQLStatements.put(String.valueOf(idx), statement);
            }
        }

        return sqlStatements;
    }

    public void update(String traceId, String spanId, String parentSpanId, String tenantId, JSONArray datas, UserAuthorizationService userAuthorizationService) throws Exception
    {
        UpdateStatementTransformation transformer = new UpdateStatementTransformation(
                new SchemaCacheWrapper(this.schemaCache), this.sqlStatementCacheWrapper, this.queryService);

        JSONObject sqlStatements = new JSONObject();
        JSONObject noSQLStatements = new JSONObject();
        for (int idx = 0; idx < datas.length(); idx++)
        {
            JSONObject statement = transformer.getStatement(traceId, 
                    spanId, 
                    parentSpanId, 
                    tenantId, 
                    datas.getJSONObject(idx), 
                    userAuthorizationService, 
                    this.businessRuleService);
            if (statement.getString(Constant.dbType).equals(Constant.sql)) 
            {
                sqlStatements.put(String.valueOf(idx), statement);
            }
            else
            {
                noSQLStatements.put(String.valueOf(idx), statement);
            }
        }

        if (sqlStatements.length() > 0)
        {
            this.sqlDriverRemote.toUpdate(traceId, spanId, parentSpanId, tenantId, sqlStatements.toString());

            for (String sqlStatementKey : sqlStatements.keySet()) 
            {
                JSONObject sqlStatement = sqlStatements.getJSONObject(sqlStatementKey);
                if (sqlStatement.has(Constant.call))
                {
                    JSONObject brCallDef = sqlStatement.getJSONObject(Constant.call);
                    for (int idx = 0; idx < brCallDef.getJSONArray(Constant.after).length(); idx++) 
                    {
                        String uri = brCallDef.getJSONArray(Constant.after).getString(idx);
                        try
                        {
                            businessRuleService.brCall(uri, "after", "update", datas.getJSONObject(Integer.parseInt(sqlStatementKey)));
                        }
                        catch (Exception e)
                        {
                            throw new RuntimeException("417?:an error occurred while calling the business rule for data pos-processing. [to: ".concat(uri).concat("]"), e);
                        }
                    }
                }
            }
        }
    }

    public JSONObject getUpdateStatements(String traceId, String spanId, String parentSpanId, String tenantId, JSONArray datas, UserAuthorizationService userAuthorizationService) throws Exception
    {
        UpdateStatementTransformation transformer = new UpdateStatementTransformation(
                new SchemaCacheWrapper(this.schemaCache), this.sqlStatementCacheWrapper, this.queryService);

        JSONObject sqlStatements = new JSONObject();
        JSONObject noSQLStatements = new JSONObject();
        for (int idx = 0; idx < datas.length(); idx++)
        {
            JSONObject sqlStatement = transformer.getStatement(traceId, 
                    spanId, 
                    parentSpanId, 
                    tenantId, 
                    datas.getJSONObject(idx), 
                    userAuthorizationService, 
                    this.businessRuleService);
            if (sqlStatement.getString(Constant.dbType).equals(Constant.sql)) 
            {
                sqlStatements.put(String.valueOf(idx), sqlStatement);
            }
            else
            {
                noSQLStatements.put(String.valueOf(idx), sqlStatement);
            }
        }

        return sqlStatements;
    }

    public void delete(String traceId, String spanId, String parentSpanId, String tenantId, JSONArray datas, UserAuthorizationService userAuthorizationService) throws Exception
    {
        DeleteStatementTransformation transformer = new DeleteStatementTransformation(
                new SchemaCacheWrapper(this.schemaCache), this.sqlStatementCacheWrapper);

        JSONObject sqlStatements = new JSONObject();
        JSONObject noSQLStatements = new JSONObject();
        for (int idx = 0; idx < datas.length(); idx++)
        {
            JSONObject statement = transformer.getStatement(tenantId, datas.getJSONObject(idx), userAuthorizationService, this.businessRuleService);
            if (statement.getString(Constant.dbType).equals(Constant.sql)) 
            {
                sqlStatements.put(String.valueOf(idx), statement);
            }
            else
            {
                noSQLStatements.put(String.valueOf(idx), statement);
            }
        }

        if (sqlStatements.length() > 0)
        {
            this.sqlDriverRemote.toDelete(traceId, spanId, parentSpanId, tenantId, sqlStatements.toString());

            for (String sqlStatementKey : sqlStatements.keySet()) 
            {
                JSONObject sqlStatement = sqlStatements.getJSONObject(sqlStatementKey);
                if (sqlStatement.has(Constant.call))
                {
                    JSONObject brCallDef = sqlStatement.getJSONObject(Constant.call);
                    for (int idx = 0; idx < brCallDef.getJSONArray(Constant.after).length(); idx++) 
                    {
                        String uri = brCallDef.getJSONArray(Constant.after).getString(idx);
                        try
                        {
                            businessRuleService.brCall(uri, "after", "delete", datas.getJSONObject(Integer.parseInt(sqlStatementKey)));
                        }
                        catch (Exception e)
                        {
                            throw new RuntimeException("417?:an error occurred while calling the business rule for data pos-processing. [to: ".concat(uri).concat("]"), e);
                        }
                    }
                }
            }
        }
    }

    public JSONObject getDeleteStatements(String tenantId, JSONArray datas, UserAuthorizationService userAuthorizationService) throws Exception
    {
        DeleteStatementTransformation transformer = new DeleteStatementTransformation(
                new SchemaCacheWrapper(this.schemaCache), this.sqlStatementCacheWrapper);

        JSONObject sqlStatements = new JSONObject();
        JSONObject noSQLStatements = new JSONObject();
        for (int idx = 0; idx < datas.length(); idx++)
        {
            JSONObject statement = transformer.getStatement(tenantId, datas.getJSONObject(idx), userAuthorizationService, this.businessRuleService);
            if (statement.getString(Constant.dbType).equals(Constant.sql)) 
            {
                sqlStatements.put(String.valueOf(idx), statement);
            }
            else
            {
                noSQLStatements.put(String.valueOf(idx), statement);
            }
        }

        return sqlStatements;
    }

    private void setDataTreeIdValues(JSONObject dataFromDs, JSONObject data)
    {
        dataFromDs.keySet().forEach(attributeName ->
        {
            if (Constant.id.equals(attributeName))
            {
                data.getJSONObject(data.keys().next()).put(Constant.id, dataFromDs.getLong(Constant.id));
            }
            else
            {
                setDataTreeIdValues(dataFromDs.getJSONObject(attributeName), data.getJSONObject(attributeName));
            }
        });
    }

    public void executeSqlStatements(String traceId, String spanId, String parentSpanId, String tenantId, JSONObject sqlStatements) throws Exception 
    {
        this.sqlDriverRemote.executeStatements(traceId, spanId, parentSpanId, tenantId, sqlStatements.toString());
    }
}
