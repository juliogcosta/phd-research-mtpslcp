package com.f.exp.jpa.queuing;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.yc.utils.ExchangeSender;

@Component
public class ExchangeSenderImpl implements ExchangeSender
{
    final Logger logger = LoggerFactory.getLogger(getClass());

    @Autowired
    private RabbitTemplate rabbitTemplate;

    @Value("${yc.eh.exchange.error.name}")
    private String errorExchangeName;

    @Value("${yc.eh.exchange.consumption.name}")
    private String consumptionExchangeName;

    @Override
    public void sendMessageToInternalErrorExchange(String message)
    {
        this.rabbitTemplate.convertAndSend(this.errorExchangeName, "internal", message);
    }

    @Override
    public void sendMessageToConsumptionExchange(String message)
    {
        this.rabbitTemplate.convertAndSend(this.consumptionExchangeName, "consumption", message);
    }

    @Override
    public void sendMessageToExternalErrorExchange(String message)
    {
        throw new RuntimeException("unimplemented method");
    }

    @Override
    public void sendMessageToPersistenceCInterruptionExchange(String message)
    {
        throw new RuntimeException("unimplemented method");
    }

    @Override
    public void sendMessageToPersistenceQInterruptionExchange(String message)
    {
        throw new RuntimeException("unimplemented method");
    }

    @Override
    public void sendMessageToMaestroInterruptionExchange(String message)
    {
        throw new RuntimeException("unimplemented method");
    }
}
