package com.f.exp.jpa.service;

import org.json.JSONObject;

import com.yc.utils.bean.LocalCacheImpl;

import br.edu.ufrn.loco3.schema.SchemaService;

class SchemaCacheWrapper implements SchemaService
{
    final static public String SCHEMA_NAME = "SCHEMA_NAME";

    private LocalCacheImpl schemaCache;

    public SchemaCacheWrapper(LocalCacheImpl schemaCache) 
    {
        this.schemaCache = schemaCache;
    }

    @Override
    public String getSchemaName(String tenantId)
    {
        Object value = this.schemaCache.getValueByKeyAndSubKey(tenantId, SCHEMA_NAME);
        if (value == null)
        {
            return null;
        }
        else 
        {
            return value.toString();
        }
    }

    @Override
    public JSONObject getOOStatements(String tenantId)
    {
        return ((JSONObject) this.schemaCache.getResource(tenantId));
    }

    @Override
    public String getOrganizationUuid(String tenantId)
    {

        return null;
    }
}