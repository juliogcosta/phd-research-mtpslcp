package com.f.exp.jpa.rest;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import com.yc.pr.models.User;
import com.yc.utils.bean.LocalCacheImpl;

public class Controller extends com.yc.utils.Controller
{
    public enum Command { CREATE, READ, UPDATE, DELETE };

    @Autowired
    protected LocalCacheImpl schemaCache;

    public void checkTenantIDAuthority(@NotNull User user, @NotNull @NotBlank String tenantId) throws Exception
    {
        if (!user.getTenantIDs().contains(tenantId))
        {
            throw new Exception(String.valueOf(HttpStatus.FORBIDDEN.value()).concat(":forbidden request."));
        }
    }

    public void registerConsumption(String tenantId, String httpEndpoint, Integer length, Integer type, Integer action, Long datetime, Long latency)
    {
        final JSONObject consumption = new JSONObject();
        consumption.put("tenantId", tenantId);
        consumption.put("endpointUrl", httpEndpoint); 
        consumption.put("length", length);
        consumption.put("type", type);
        consumption.put("action", action);
        consumption.put("latency", latency);
        consumption.put("datetime", datetime);

        try
        {
            super.exchangeSender.sendMessageToConsumptionExchange(consumption.toString());
        }
        catch (Exception e)
        {
            if (super.errorControl.containsKey(tenantId)) 
            {
                if (super.errorControl.getLogConsole(tenantId)) 
                {
                    e.printStackTrace();
                }
            }
            else
            {
                e.printStackTrace();
            }
        }
    }
}
