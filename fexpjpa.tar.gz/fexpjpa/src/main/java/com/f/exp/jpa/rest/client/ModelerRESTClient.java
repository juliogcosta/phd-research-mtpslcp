package com.f.exp.jpa.rest.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;

import feign.Headers;
import feign.Param;
import feign.RequestLine;

@FeignClient(name = "${yc.feign.mapping.modeler.name}")
public interface ModelerRESTClient
{
    static final String urlPrefix = "/a35gry2b4d8ops/unsecured";

    @RequestLine("GET "+ModelerRESTClient.urlPrefix+"/project/tenant-id/{tenantId}")
    @Headers(value = { "Accept: application/json",
            "x-b3-traceid: {traceId}",
            "x-b3-spanid: {spanId}",
            "x-b3-parentspanid: {parentSpanId}" })
    public ResponseEntity<String> getProjectByTenantId(
            @Param("traceId") String traceId,
            @Param("spanId") String spanId,
            @Param("parentSpanId") String parentSpanId,
            @Param("tenantId") String tenantId) throws Exception;
}
